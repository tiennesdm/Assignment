const model = require('./model');
module.exports = model;